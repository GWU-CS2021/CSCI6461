# TODO
# This can be init in CPU constants.












