# CSCI6461

# DDL
- Term Paper Topic Due 1/18
- Project Part 1 Due Midnight ~~1/30~~ 02/06
- Project Part 2 Due Midnight  3/5
- Term Paper Due Midnight 3/26
- Project Part 3 Due Midnight  4/2
- Project Part 4 Due Midnight 4/25
- Final 4/19

# Links
- https://www.mslcourses.com/CSCI6461Section10Spring2022/
- https://www.mslcourses.com/CSCI6461Section10Spring2022/Schedule6461Section10Spring2022.html
