from os.path import dirname, abspath

ROOT_DIR = dirname(abspath(__file__))